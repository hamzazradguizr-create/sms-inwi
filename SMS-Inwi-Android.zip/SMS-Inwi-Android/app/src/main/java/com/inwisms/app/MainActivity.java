package com.inwisms.app;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.material.tabs.TabLayout;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    static final int PERM_SMS = 1001;
    static final String PREF_CONTACTS = "contacts";
    static final String PREF_TEMPLATE = "template";
    static final String PREF_DELAY = "delay";
    static final String PREF_SIM = "simSlot";

    Gson gson = new Gson();
    SharedPreferences prefs;
    List<Contact> contacts = new ArrayList<>();

    // UI
    TabLayout tabLayout;
    LinearLayout tabNumeros, tabEnvoi, tabConfig;
    ListView listView;
    ContactAdapter adapter;
    TextView tvStats, tvLog, tvProgress;
    ProgressBar progressBar;
    EditText etTemplate, etDelay;
    Spinner spinnerSim;
    Button btnSend, btnAddNum, btnImport;
    int selectedSim = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("SMSInwi", MODE_PRIVATE);
        loadContacts();

        setupUI();
        checkPermissions();
        detectSims();
    }

    void setupUI() {
        tabLayout = findViewById(R.id.tabLayout);
        tabNumeros = findViewById(R.id.tabNumeros);
        tabEnvoi = findViewById(R.id.tabEnvoi);
        tabConfig = findViewById(R.id.tabConfig);
        listView = findViewById(R.id.listView);
        tvStats = findViewById(R.id.tvStats);
        tvLog = findViewById(R.id.tvLog);
        tvProgress = findViewById(R.id.tvProgress);
        progressBar = findViewById(R.id.progressBar);
        etTemplate = findViewById(R.id.etTemplate);
        etDelay = findViewById(R.id.etDelay);
        spinnerSim = findViewById(R.id.spinnerSim);
        btnSend = findViewById(R.id.btnSend);
        btnAddNum = findViewById(R.id.btnAddNum);
        btnImport = findViewById(R.id.btnImport);

        // Charger config
        etTemplate.setText(prefs.getString(PREF_TEMPLATE, "Recharge de {{montant}} DH effectuee. Merci."));
        etDelay.setText(String.valueOf(prefs.getInt(PREF_DELAY, 3000)));

        // Adapter liste
        adapter = new ContactAdapter(this, contacts);
        listView.setAdapter(adapter);

        // Tabs
        tabLayout.addTab(tabLayout.newTab().setText("Numéros"));
        tabLayout.addTab(tabLayout.newTab().setText("Envoi"));
        tabLayout.addTab(tabLayout.newTab().setText("Paramètres"));
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            public void onTabSelected(TabLayout.Tab tab) { showTab(tab.getPosition()); }
            public void onTabUnselected(TabLayout.Tab tab) {}
            public void onTabReselected(TabLayout.Tab tab) {}
        });
        showTab(0);
        updateStats();

        // Ajouter numéro
        btnAddNum.setOnClickListener(v -> showAddDialog());

        // Import CSV
        btnImport.setOnClickListener(v -> showImportDialog());

        // Bouton envoi
        btnSend.setOnClickListener(v -> startBulkSend());

        // Sauvegarder config
        findViewById(R.id.btnSaveConfig).setOnClickListener(v -> saveConfig());

        // Sélection SIM
        spinnerSim.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v2, int pos, long id) { selectedSim = pos; }
            public void onNothingSelected(AdapterView<?> p) {}
        });
    }

    void showTab(int i) {
        tabNumeros.setVisibility(i == 0 ? View.VISIBLE : View.GONE);
        tabEnvoi.setVisibility(i == 1 ? View.VISIBLE : View.GONE);
        tabConfig.setVisibility(i == 2 ? View.VISIBLE : View.GONE);
    }

    void detectSims() {
        List<String> simLabels = new ArrayList<>();
        simLabels.add("SIM 1 (par défaut)");
        simLabels.add("SIM 2");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1
                && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            try {
                SubscriptionManager sm = (SubscriptionManager) getSystemService(TELEPHONY_SUBSCRIPTION_SERVICE);
                List<SubscriptionInfo> subs = sm.getActiveSubscriptionInfoList();
                if (subs != null && !subs.isEmpty()) {
                    simLabels.clear();
                    for (SubscriptionInfo s : subs) {
                        simLabels.add("SIM " + (s.getSimSlotIndex() + 1) + " — " + s.getCarrierName() + " (" + s.getNumber() + ")");
                    }
                }
            } catch (Exception e) { /* ignorer */ }
        }

        ArrayAdapter<String> simAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, simLabels);
        simAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSim.setAdapter(simAdapter);
        selectedSim = prefs.getInt(PREF_SIM, 0);
        if (selectedSim < simLabels.size()) spinnerSim.setSelection(selectedSim);
    }

    void showAddDialog() {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("Ajouter un numéro");
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_add, null);
        EditText etNum = v.findViewById(R.id.etDialogNum);
        EditText etAmt = v.findViewById(R.id.etDialogAmount);
        EditText etName = v.findViewById(R.id.etDialogName);
        b.setView(v);
        b.setPositiveButton("Ajouter", (d, w) -> {
            String num = etNum.getText().toString().trim();
            String amt = etAmt.getText().toString().trim();
            String name = etName.getText().toString().trim();
            if (!num.matches("(06|07)\\d{8}")) {
                toast("Numéro invalide (ex: 0612345678)"); return;
            }
            if (amt.isEmpty()) { toast("Entrez un montant"); return; }
            contacts.add(new Contact(name.isEmpty() ? num : name, num, Integer.parseInt(amt), "pending"));
            adapter.notifyDataSetChanged();
            saveContacts();
            updateStats();
        });
        b.setNegativeButton("Annuler", null);
        b.show();
    }

    void showImportDialog() {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("Import en masse");
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_import, null);
        EditText etCsv = v.findViewById(R.id.etCsv);
        etCsv.setHint("0612345678,20\n0687654321,50\n0711111111,10");
        b.setView(v);
        b.setPositiveButton("Importer", (d, w) -> {
            String[] lines = etCsv.getText().toString().trim().split("\n");
            int added = 0;
            for (String line : lines) {
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    String num = parts[0].trim();
                    String amt = parts[1].trim();
                    String name = parts.length > 2 ? parts[2].trim() : num;
                    if (num.matches("(06|07)\\d{8}") && amt.matches("\\d+")) {
                        contacts.add(new Contact(name, num, Integer.parseInt(amt), "pending"));
                        added++;
                    }
                }
            }
            adapter.notifyDataSetChanged();
            saveContacts();
            updateStats();
            toast(added + " numéro(s) importé(s)");
        });
        b.setNegativeButton("Annuler", null);
        b.show();
    }

    void startBulkSend() {
        List<Contact> pending = new ArrayList<>();
        for (Contact c : contacts) if ("pending".equals(c.status)) pending.add(c);
        if (pending.isEmpty()) { toast("Aucun numéro en attente"); return; }

        int delay = 3000;
        try { delay = Integer.parseInt(etDelay.getText().toString()); } catch (Exception e) {}
        String template = etTemplate.getText().toString();

        btnSend.setEnabled(false);
        progressBar.setMax(pending.size());
        progressBar.setProgress(0);
        tvLog.setText("");

        final int delayMs = delay;
        final String tpl = template;
        final int simSlot = selectedSim;
        final List<Contact> toSend = pending;
        final int[] idx = {0};

        Runnable sendNext = new Runnable() {
            @Override
            public void run() {
                if (idx[0] >= toSend.size()) {
                    btnSend.setEnabled(true);
                    long sent = contacts.stream().filter(c -> "sent".equals(c.status)).count();
                    long failed = contacts.stream().filter(c -> "failed".equals(c.status)).count();
                    appendLog("✅ Terminé — " + sent + " envoyés, " + failed + " échoués");
                    saveContacts();
                    return;
                }
                Contact c = toSend.get(idx[0]);
                String msg = buildMessage(tpl, c.numero, c.montant);
                appendLog("📤 " + c.numero + " (" + c.montant + " DH)...");

                boolean ok = SmsHelper.sendSMS(MainActivity.this, c.numero, msg, simSlot);
                c.status = ok ? "sent" : "failed";
                appendLog(ok ? "   ✓ Envoyé" : "   ✗ Échec");

                // Trouver le contact dans la liste principale et mettre à jour
                for (Contact main : contacts) {
                    if (main.numero.equals(c.numero)) { main.status = c.status; break; }
                }
                adapter.notifyDataSetChanged();
                updateStats();

                int done = idx[0] + 1;
                progressBar.setProgress(done);
                tvProgress.setText(done + " / " + toSend.size());

                idx[0]++;
                btnSend.postDelayed(this, delayMs);
            }
        };
        btnSend.post(sendNext);
    }

    String buildMessage(String tpl, String numero, int montant) {
        return tpl
            .replace("{{montant}}", String.valueOf(montant))
            .replace("{{numero}}", numero)
            .replace("{{date}}", java.text.DateFormat.getDateInstance().format(new Date()));
    }

    void appendLog(String line) {
        String current = tvLog.getText().toString();
        tvLog.setText(current + line + "\n");
    }

    void updateStats() {
        long total = contacts.size();
        long sent = contacts.stream().filter(c -> "sent".equals(c.status)).count();
        long pending = contacts.stream().filter(c -> "pending".equals(c.status)).count();
        long failed = contacts.stream().filter(c -> "failed".equals(c.status)).count();
        int totalDH = contacts.stream().mapToInt(c -> c.montant).sum();
        tvStats.setText("Total: " + total + "  |  En attente: " + pending + "  |  Envoyés: " + sent + "  |  Échoués: " + failed + "  |  " + totalDH + " DH");
    }

    void saveConfig() {
        prefs.edit()
            .putString(PREF_TEMPLATE, etTemplate.getText().toString())
            .putInt(PREF_DELAY, Integer.parseInt(etDelay.getText().toString().isEmpty() ? "3000" : etDelay.getText().toString()))
            .putInt(PREF_SIM, selectedSim)
            .apply();
        toast("Configuration sauvegardée");
    }

    void saveContacts() {
        prefs.edit().putString(PREF_CONTACTS, gson.toJson(contacts)).apply();
    }

    void loadContacts() {
        String json = prefs.getString(PREF_CONTACTS, "[]");
        Type t = new TypeToken<List<Contact>>(){}.getType();
        contacts = gson.fromJson(json, t);
        if (contacts == null) contacts = new ArrayList<>();
    }

    void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    void checkPermissions() {
        String[] perms = {
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_PHONE_NUMBERS,
            Manifest.permission.READ_CONTACTS
        };
        List<String> needed = new ArrayList<>();
        for (String p : perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) needed.add(p);
        }
        if (!needed.isEmpty()) ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), PERM_SMS);
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] perms, @NonNull int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == PERM_SMS) {
            detectSims();
            for (int r : results) {
                if (r != PackageManager.PERMISSION_GRANTED) {
                    toast("Permission SMS refusée — l'application ne peut pas envoyer de SMS");
                    return;
                }
            }
            toast("Permissions accordées ✓");
        }
    }
}
