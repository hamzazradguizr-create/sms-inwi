package com.inwisms.app;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import android.util.Log;

public class SmsSentReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        int result = getResultCode();

        if ("SMS_SENT".equals(action)) {
            switch (result) {
                case Activity.RESULT_OK:
                    Log.d("SMS", "SMS envoyé avec succès");
                    break;
                case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                    Log.e("SMS", "Erreur générique");
                    break;
                case SmsManager.RESULT_ERROR_NO_SERVICE:
                    Log.e("SMS", "Pas de service réseau");
                    break;
                case SmsManager.RESULT_ERROR_NULL_PDU:
                    Log.e("SMS", "PDU null");
                    break;
                case SmsManager.RESULT_ERROR_RADIO_OFF:
                    Log.e("SMS", "Radio désactivée");
                    break;
            }
        } else if ("SMS_DELIVERED".equals(action)) {
            if (result == Activity.RESULT_OK) {
                Log.d("SMS", "SMS livré au destinataire");
            }
        }
    }
}
