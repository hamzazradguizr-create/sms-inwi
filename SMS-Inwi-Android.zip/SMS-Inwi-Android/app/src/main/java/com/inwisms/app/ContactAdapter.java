package com.inwisms.app;

import android.content.Context;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.List;

public class ContactAdapter extends ArrayAdapter<Contact> {
    private final List<Contact> contacts;
    private final Context ctx;

    public ContactAdapter(Context ctx, List<Contact> contacts) {
        super(ctx, 0, contacts);
        this.ctx = ctx;
        this.contacts = contacts;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(ctx).inflate(R.layout.item_contact, parent, false);
        }
        Contact c = contacts.get(position);

        TextView tvName = convertView.findViewById(R.id.tvName);
        TextView tvNum = convertView.findViewById(R.id.tvNum);
        TextView tvAmt = convertView.findViewById(R.id.tvAmt);
        TextView tvStatus = convertView.findViewById(R.id.tvStatus);
        CheckBox cbSelect = convertView.findViewById(R.id.cbSelect);
        ImageButton btnDelete = convertView.findViewById(R.id.btnDelete);

        tvName.setText(c.name);
        tvNum.setText(c.numero);
        tvAmt.setText(c.montant + " DH");

        switch (c.status) {
            case "sent":
                tvStatus.setText("✓ Envoyé");
                tvStatus.setTextColor(Color.parseColor("#1a7a4a"));
                tvStatus.setBackgroundColor(Color.parseColor("#e8f5ee"));
                break;
            case "failed":
                tvStatus.setText("✗ Échec");
                tvStatus.setTextColor(Color.parseColor("#c0392b"));
                tvStatus.setBackgroundColor(Color.parseColor("#fdecea"));
                break;
            default:
                tvStatus.setText("⏳ Attente");
                tvStatus.setTextColor(Color.parseColor("#d4750a"));
                tvStatus.setBackgroundColor(Color.parseColor("#fef3e2"));
                break;
        }

        cbSelect.setChecked("pending".equals(c.status));
        cbSelect.setEnabled(!"sent".equals(c.status));

        btnDelete.setOnClickListener(v -> {
            contacts.remove(position);
            notifyDataSetChanged();
        });

        return convertView;
    }
}
