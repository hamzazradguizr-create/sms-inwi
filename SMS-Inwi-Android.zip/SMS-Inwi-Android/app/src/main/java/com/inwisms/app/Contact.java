package com.inwisms.app;

public class Contact {
    public String name;
    public String numero;
    public int montant;
    public String status; // "pending", "sent", "failed"

    public Contact(String name, String numero, int montant, String status) {
        this.name = name;
        this.numero = numero;
        this.montant = montant;
        this.status = status;
    }
}
