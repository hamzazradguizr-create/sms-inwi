package com.inwisms.app;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.telephony.SmsManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.List;

public class SmsHelper {

    /**
     * Envoie un SMS via le slot SIM spécifié (0 = SIM1, 1 = SIM2)
     * Gère automatiquement les messages longs (>160 chars)
     */
    public static boolean sendSMS(Context ctx, String numero, String message, int simSlot) {
        try {
            SmsManager smsManager;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                // Essayer d'utiliser la SIM sélectionnée
                try {
                    SubscriptionManager sm = (SubscriptionManager) ctx.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
                    List<SubscriptionInfo> subs = sm.getActiveSubscriptionInfoList();
                    if (subs != null && simSlot < subs.size()) {
                        int subId = subs.get(simSlot).getSubscriptionId();
                        smsManager = SmsManager.getSmsManagerForSubscriptionId(subId);
                    } else {
                        smsManager = SmsManager.getDefault();
                    }
                } catch (Exception e) {
                    smsManager = SmsManager.getDefault();
                }
            } else {
                smsManager = SmsManager.getDefault();
            }

            // Intent pour confirmer l'envoi
            Intent sentIntent = new Intent("SMS_SENT");
            PendingIntent sentPI = PendingIntent.getBroadcast(ctx, 0, sentIntent,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

            Intent deliveredIntent = new Intent("SMS_DELIVERED");
            PendingIntent deliveredPI = PendingIntent.getBroadcast(ctx, 0, deliveredIntent,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

            // Message long → diviser automatiquement
            if (message.length() > 160) {
                ArrayList<String> parts = smsManager.divideMessage(message);
                ArrayList<PendingIntent> sentList = new ArrayList<>();
                ArrayList<PendingIntent> deliveredList = new ArrayList<>();
                for (String part : parts) {
                    sentList.add(sentPI);
                    deliveredList.add(deliveredPI);
                }
                smsManager.sendMultipartTextMessage(numero, null, parts, sentList, deliveredList);
            } else {
                smsManager.sendTextMessage(numero, null, message, sentPI, deliveredPI);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
