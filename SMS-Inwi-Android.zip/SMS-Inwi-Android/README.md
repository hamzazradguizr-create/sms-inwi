# SMS Inwi — Application Android
## Envoi de SMS de recharge en masse via votre SIM Inwi

---

## 📱 Fonctionnalités
- Ajouter des numéros un par un ou importer une liste CSV
- Définir un montant de recharge par numéro
- Sélectionner la SIM Inwi (support double SIM)
- Envoyer tous les SMS automatiquement avec délai configurable
- Variables dans le message : {{montant}}, {{numero}}, {{date}}
- Journal d'envoi en temps réel
- Statuts : En attente / Envoyé / Échec

---

## 🔨 Comment compiler et installer (Android Studio)

### Étape 1 — Installer Android Studio
Télécharger depuis https://developer.android.com/studio
Installer et lancer Android Studio.

### Étape 2 — Ouvrir le projet
1. Ouvrir Android Studio
2. Cliquer "Open an Existing Project"
3. Sélectionner le dossier SMS-Inwi-Android
4. Attendre la synchronisation Gradle (quelques minutes)

### Étape 3 — Compiler l'APK
Menu Build → Build Bundle(s) / APK(s) → Build APK(s)
L'APK sera généré dans :
app/build/outputs/apk/debug/app-debug.apk

### Étape 4 — Installer sur le téléphone
Option A — Câble USB :
  1. Activer "Options développeur" sur le téléphone
     (Paramètres → À propos → Numéro de build × 7)
  2. Activer "Débogage USB"
  3. Brancher le câble USB
  4. Dans Android Studio : Run → Run 'app'

Option B — Copier l'APK directement :
  1. Copier app-debug.apk sur le téléphone (WhatsApp, email, USB...)
  2. Ouvrir l'APK depuis le gestionnaire de fichiers
  3. Autoriser "Sources inconnues" si demandé

---

## ⚙️ Prérequis
- Android 5.0 (API 21) ou supérieur
- SIM Inwi insérée
- Autoriser les permissions SMS au premier lancement

---

## 📋 Format d'import CSV
Un numéro par ligne, format : numero,montant,nom
Exemple :
0612345678,20,Ahmed
0687654321,50
0711111111,10,Sara Alaoui

---

## 📝 Variables du message
{{montant}} → remplacé par le montant en DH
{{numero}} → remplacé par le numéro du destinataire
{{date}} → remplacé par la date du jour

Exemple de message :
"Recharge de {{montant}} DH effectuée le {{date}}. Merci."

---

## ⚠️ Notes importantes
- L'application utilise l'API SMS native d'Android
- Chaque SMS envoyé sera débité de votre crédit Inwi normalement
- Respectez un délai de 2-3 secondes entre chaque envoi
- Pour les messages > 160 caractères, ils sont automatiquement découpés
- Testé sur Android 10, 11, 12, 13, 14

---

Structure du projet :
SMS-Inwi-Android/
├── app/src/main/
│   ├── AndroidManifest.xml
│   ├── java/com/inwisms/app/
│   │   ├── MainActivity.java     ← Interface principale
│   │   ├── ContactAdapter.java   ← Liste des numéros
│   │   ├── Contact.java          ← Modèle de données
│   │   ├── SmsHelper.java        ← Envoi SMS + double SIM
│   │   ├── SmsService.java       ← Service arrière-plan
│   │   └── SmsSentReceiver.java  ← Suivi des envois
│   └── res/layout/
│       ├── activity_main.xml     ← Layout principal
│       ├── item_contact.xml      ← Ligne de liste
│       ├── dialog_add.xml        ← Dialogue ajout
│       └── dialog_import.xml     ← Dialogue import
└── README.md
